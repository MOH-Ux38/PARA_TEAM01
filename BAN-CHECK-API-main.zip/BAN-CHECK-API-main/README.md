```markdown
# Free Fire Player Checker API

A Flask-based API for checking Free Fire player details, including nickname, region, ban status, and ban period, with multi-region support (IN, BD, PK, NA, SG).

## Installation

Clone the repository and install dependencies:

```
**git clone <your-repo-url>**
**cd <your-repo-directory>**
**pip install flask requests**
```

## Usage

Run the app locally:

```
**python app.py**
```

Access the endpoint: `http://127.0.0.1:5000/check?uid=<player_uid>&region=<region_code>`

Example response:
```
```
{
  "success": true,
  "nickname": "PlayerName",
  "region": "IN",
  "is_banned": false,
  "ban_period": 0,
  "message": "Player found and data retrieved successfully."
}```
```

## Technologies

- Python 3.x
- Flask for the web framework[5].
- Requests for API calls.

## Features

- Multi-region support for Free Fire servers.
- Ban status checking via Garena API.
- Error handling for invalid UIDs or regions.

## Contributing

Fork the repo, create a branch, and submit a pull request[2].

## License

MIT License[2].
```
